<?php
namespace App\Entity\Repository;

use App\Entity;
use Azura\Doctrine\Repository;

class StationMediaMetadataRepository extends Repository
{

}
