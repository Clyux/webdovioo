<?php

namespace App\Entity\Migration;

use Doctrine\Migrations\AbstractMigration;
use Doctrine\DBAL\Schema\Schema;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20171022005913 extends AbstractMigration
{
    /**
     * @param Schema $schema
     */
    public function up(Schema $schema)
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE station_mounts ADD remote_type VARCHAR(50) DEFAULT NULL, ADD remote_url VARCHAR(255) DEFAULT NULL, ADD remote_mount VARCHAR(150) DEFAULT NULL, ADD remote_source_username VARCHAR(100) DEFAULT NULL, ADD remote_source_password VARCHAR(100) DEFAULT NULL');
    }

    /**
     * @param Schema $schema
     */
    public function down(Schema $schema)
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->abortIf($this->connection->getDatabasePlatform()->getName() !== 'mysql', 'Migration can only be executed safely on \'mysql\'.');

        $this->addSql('ALTER TABLE station_mounts DROP remote_type, remote_url, DROP remote_mount, DROP remote_source_username, DROP remote_source_password');
    }
}
