<?php
namespace App\Http;

class Response extends \Azura\Http\Response
{
    // Empty class to preserve consistency with \App\Http\Request
}
