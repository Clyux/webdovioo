<?php
namespace App\Controller\Stations;

use App\Form\StationForm;
use Doctrine\ORM\EntityManager;
use App\Entity;
use App\Http\Request;
use App\Http\Response;
use Psr\Http\Message\ResponseInterface;

class ProfileController
{
    /** @var EntityManager */
    protected $em;

    /** @var Entity\Repository\StationRepository */
    protected $station_repo;

    /** @var StationForm */
    protected $station_form;

    /**
     * @param EntityManager $em
     * @param StationForm $station_form
     *
     * @see \App\Provider\StationsProvider
     */
    public function __construct(
        EntityManager $em,
        StationForm $station_form
    )
    {
        $this->em = $em;
        $this->station_repo = $em->getRepository(Entity\Station::class);

        $this->station_form = $station_form;
    }

    public function __invoke(Request $request, Response $response): ResponseInterface
    {
        $station = $request->getStation();
        $view = $request->getView();

        if (!$station->isEnabled()) {
            return $view->renderToResponse($response, 'stations/profile/disabled');
        }

        $frontend = $request->getStationFrontend();
        $remotes = $request->getStationRemotes();

        $stream_urls = [
            'local' => [],
            'remote' => [],
        ];

        foreach ($station->getMounts() as $mount) {
            $stream_urls['local'][] = [
                $mount->getDisplayName(),
                (string)$frontend->getUrlForMount($station, $mount),
            ];
        }

        foreach($remotes as $ra_proxy) {
            $remote = $ra_proxy->getRemote();

            $stream_urls['remote'][] = [
                $remote->getDisplayName(),
                (string)$ra_proxy->getAdapter()->getPublicUrl($remote)
            ];
        }

        // Statistics about backend playback.
        $num_songs = $this->em->createQuery(/** @lang DQL */ 'SELECT COUNT(sm.id) 
            FROM App\Entity\StationMedia sm 
            LEFT JOIN sm.playlist_items spm 
            LEFT JOIN spm.playlist sp 
            WHERE sp.id IS NOT NULL 
            AND sm.station_id = :station_id')
            ->setParameter('station_id', $station->getId())
            ->getSingleScalarResult();

        $num_playlists = $this->em->createQuery(/** @lang DQL */ 'SELECT COUNT(sp.id) 
            FROM App\Entity\StationPlaylist sp 
            WHERE sp.station_id = :station_id')
            ->setParameter('station_id', $station->getId())
            ->getSingleScalarResult();

        // Populate initial nowplaying data.
        $np = [
            'now_playing' => [
                'song' => [
                    'title' => __('Song Title'),
                    'artist' => __('Song Artist'),
                ],
                'playlist' => '',
                'is_request' => false,
                'elapsed' => 0,
                'duration' => 0,
            ],
            'listeners' => [
                'unique' => 0,
                'total' => 0,
            ],
            'live' => [
                'is_live' => false,
                'streamer_name' => '',
            ],
            'playing_next' => [
                'song' => [
                    'title' => __('Song Title'),
                    'artist' => __('Song Artist'),
                ],
                'playlist' => '',
            ],
        ];

        $station_np = $station->getNowplaying();
        if ($station_np instanceof Entity\Api\NowPlaying) {
            $np = array_intersect_key($station_np->toArray(), $np) + $np;
        }

        return $view->renderToResponse($response, 'stations/profile/index', [
            'num_songs' => $num_songs,
            'num_playlists' => $num_playlists,
            'stream_urls' => $stream_urls,
            'backend_type' => $station->getBackendType(),
            'backend_config' => (array)$station->getBackendConfig(),
            'frontend_type' => $station->getFrontendType(),
            'frontend_config' => (array)$station->getFrontendConfig(),
            'nowplaying' => $np,
        ]);
    }

    public function editAction(Request $request, Response $response, $station_id): ResponseInterface
    {
        $station = $request->getStation();

        if (false !== $this->station_form->process($request, $station)) {
            return $response->withRedirect($request->getRouter()->fromHere('stations:profile:index'));
        }

        return $request->getView()->renderToResponse($response, 'stations/profile/edit', [
            'form' => $this->station_form,
        ]);
    }
}
