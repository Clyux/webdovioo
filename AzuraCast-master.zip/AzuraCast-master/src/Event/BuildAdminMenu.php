<?php
namespace App\Event;

class BuildAdminMenu extends AbstractBuildMenu
{
    public const NAME = 'build-admin-menu';
}