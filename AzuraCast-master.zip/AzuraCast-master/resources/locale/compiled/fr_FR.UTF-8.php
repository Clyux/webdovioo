<?php return array (
  'domain' => NULL,
  'plural-forms' => 'nplurals=2; plural=(n > 1);',
  'messages' => 
  array (
    '' => 
    array (
      '' => 
      array (
        0 => 'Project-Id-Version: azuracast
Report-Msgid-Bugs-To: 
Last-Translator: SlvrEagle23 <loobalightdark@gmail.com>
Language-Team: French
MIME-Version: 1.0
Content-Type: text/plain; charset=UTF-8
Content-Transfer-Encoding: 8bit
POT-Creation-Date: 2019-03-24T05:46:26+00:00
PO-Revision-Date: 2019-03-25 12:39
Language: fr_FR
Plural-Forms: nplurals=2; plural=(n > 1);
X-Generator: crowdin.com
X-Crowdin-Project: azuracast
X-Crowdin-Language: fr
X-Crowdin-File: /master/resources/locale/default.pot
',
      ),
      'This port is currently in use by another station.' => 
      array (
        0 => '',
      ),
      'All Permissions' => 
      array (
        0 => 'Toutes les permissions',
      ),
      'View Administration Page' => 
      array (
        0 => 'Voir la page d\'administration',
      ),
      'View System Logs' => 
      array (
        0 => 'Voir les journaux système',
      ),
      'Settings' => 
      array (
        0 => 'Paramètres',
      ),
      'Administer %s' => 
      array (
        0 => 'Administrer %s',
      ),
      'API Keys' => 
      array (
        0 => 'Clés API',
      ),
      'Users' => 
      array (
        0 => 'Utilisateurs',
      ),
      'Permissions' => 
      array (
        0 => 'Permissions',
      ),
      'Stations' => 
      array (
        0 => 'Stations',
      ),
      'Custom Fields' => 
      array (
        0 => 'Champs personnalisés',
      ),
      'View Station Page' => 
      array (
        0 => 'Voir la page de la station',
      ),
      'View Station Reports' => 
      array (
        0 => 'Voir les rapports de la station',
      ),
      'View Station Logs' => 
      array (
        0 => 'Voir les journaux de la station',
      ),
      'Profile' => 
      array (
        0 => 'Profil',
      ),
      'Manage Station %s' => 
      array (
        0 => 'Gérer la station %s',
      ),
      'Broadcasting' => 
      array (
        0 => '',
      ),
      'Streamers' => 
      array (
        0 => '',
      ),
      'Mount Points' => 
      array (
        0 => 'Points de montage',
      ),
      'Remote Relays' => 
      array (
        0 => 'Relais distant',
      ),
      'Media' => 
      array (
        0 => 'Médias',
      ),
      'Automation' => 
      array (
        0 => 'Automatisation',
      ),
      'Web Hooks' => 
      array (
        0 => '',
      ),
      'Now Playing Data' => 
      array (
        0 => 'Données du titre en cours',
      ),
      '1-Minute Sync' => 
      array (
        0 => 'Synchro chaque minute',
      ),
      'Song Requests Queue' => 
      array (
        0 => 'File d\'attente de la demande de titres',
      ),
      '5-Minute Sync' => 
      array (
        0 => 'Synchro chaque 5 minutes',
      ),
      'Check Media Folders' => 
      array (
        0 => 'Vérification des dossiers Media',
      ),
      '1-Hour Sync' => 
      array (
        0 => 'Synchro chaque heure',
      ),
      'Analytics/Statistics' => 
      array (
        0 => 'Performances/Statistiques',
      ),
      'Cleanup' => 
      array (
        0 => 'Nettoyage',
      ),
      'The account associated with e-mail address "%s" has been set as an administrator' => 
      array (
        0 => '',
      ),
      'Account not found.' => 
      array (
        0 => '',
      ),
      'Your <code>docker-compose.yml</code> file is out of date!' => 
      array (
        0 => 'Votre fichier <code>docker-compose.yml</code> est obsolète!',
      ),
      'You should update your <code>docker-compose.yml</code> file to reflect the newest changes. View the <a href="%s" target="_blank">latest version of the file</a> and update your file accordingly.<br>You can also use the <code>./docker.sh</code> utility script to automatically update your file.' => 
      array (
        0 => '',
      ),
      'Follow the <a href="%s" target="_blank">update instructions</a> to update your installation.' => 
      array (
        0 => '',
      ),
      'AzuraCast <a href="%s" target="_blank">version %s</a> is now available.' => 
      array (
        0 => '',
      ),
      'You are currently running version %s. Updating is highly recommended.' => 
      array (
        0 => '',
      ),
      'New AzuraCast Release Version Available' => 
      array (
        0 => '',
      ),
      'The following improvements have been made since your last update:' => 
      array (
        0 => '',
      ),
      'Your installation is currently %d update(s) behind the latest version.' => 
      array (
        0 => '',
      ),
      'You should update to take advantage of bug and security fixes.' => 
      array (
        0 => '',
      ),
      'New AzuraCast Updates Available' => 
      array (
        0 => '',
      ),
      'You must be logged in to access this page.' => 
      array (
        0 => 'Vous devez être connecté pour accéder à cette page.',
      ),
      'You do not have permission to access this portion of the site.' => 
      array (
        0 => 'Vous n’êtes pas autorisé à accéder à cette partie du site.',
      ),
      '%s cannot start' => 
      array (
        0 => '',
      ),
      'It is already running.' => 
      array (
        0 => '',
      ),
      '%s cannot stop' => 
      array (
        0 => '',
      ),
      'It is not running.' => 
      array (
        0 => '',
      ),
      '%s encountered an error' => 
      array (
        0 => '',
      ),
      'Check the log for details.' => 
      array (
        0 => '',
      ),
      'Use <b>%s</b> on this server' => 
      array (
        0 => 'Utilisez <b>%s</b> sur ce serveur',
      ),
      'Connect to a <b>remote radio server</b>' => 
      array (
        0 => '',
      ),
      '<b>Do not use</b> an AutoDJ service' => 
      array (
        0 => '',
      ),
      '%d second' => 
      array (
        0 => '%d seconde',
        1 => '%d secondes',
      ),
      '%d minute' => 
      array (
        0 => '%d minute',
        1 => '%d minutes',
      ),
      '%d hour' => 
      array (
        0 => '%d heure',
        1 => '%d heures',
      ),
      '%d day' => 
      array (
        0 => '%d jour',
        1 => '%d jours',
      ),
      '%d month' => 
      array (
        0 => '%d mois',
        1 => '%d mois',
      ),
      'This feature is not currently supported on this station.' => 
      array (
        0 => 'Cette fonctionnalité n\'est pas compatible avec cette station.',
      ),
      'Station' => 
      array (
        0 => 'Station',
      ),
      '%s restarted.' => 
      array (
        0 => '%s est redémarré.',
      ),
      'Frontend' => 
      array (
        0 => 'Frontend',
      ),
      '%s stopped.' => 
      array (
        0 => '%s est arrêtée.',
      ),
      '%s started.' => 
      array (
        0 => '%s est démarré.',
      ),
      'Song skipped.' => 
      array (
        0 => 'Le titre à été passé.',
      ),
      'Streamer disconnected.' => 
      array (
        0 => 'Streamer déconnecté.',
      ),
      'Backend' => 
      array (
        0 => 'Backend',
      ),
      'Liquidsoap Log' => 
      array (
        0 => 'Log de Liquidsoap',
      ),
      'Liquidsoap Configuration' => 
      array (
        0 => 'Configuration de liquidsoap',
      ),
      'Icecast Access Log' => 
      array (
        0 => 'Logs d’accès Icecast',
      ),
      'Icecast Error Log' => 
      array (
        0 => 'Logs d\'erreur icecast',
      ),
      'Icecast Configuration' => 
      array (
        0 => 'Configuration d’Icecast',
      ),
      'SHOUTcast Log' => 
      array (
        0 => 'Logs de SHOUTcast',
      ),
      'SHOUTcast Configuration' => 
      array (
        0 => 'Configuration de SHOUTcast',
      ),
      'AzuraCast Application Log' => 
      array (
        0 => 'Logs de l\'application AzuraCast',
      ),
      'Nginx Access Log' => 
      array (
        0 => 'Logs d’accès Nginx',
      ),
      'Nginx Error Log' => 
      array (
        0 => 'Logs d\'erreurs Nginx',
      ),
      'PHP Application Log' => 
      array (
        0 => 'Log de l\'application PHP',
      ),
      'Supervisord Log' => 
      array (
        0 => 'Log de Supervisord',
      ),
      '%s updated.' => 
      array (
        0 => '%s mis à jour.',
      ),
      '%s added.' => 
      array (
        0 => '%s ajouté.',
      ),
      'Custom Field' => 
      array (
        0 => 'Champs personnalisés',
      ),
      'Edit %s' => 
      array (
        0 => 'Modifiez le fichier %s',
      ),
      'Add %s' => 
      array (
        0 => 'Ajouter %s',
      ),
      '%s deleted.' => 
      array (
        0 => '%s supprimé.',
      ),
      'User' => 
      array (
        0 => 'Utilisateur',
      ),
      'Another user already exists with this e-mail address. Please update the e-mail address.' => 
      array (
        0 => 'Il existe déjà un autre utilisateur avec cette adresse E-mail. Veuillez modifier votre adresse E-mail.',
      ),
      'You cannot delete your own account.' => 
      array (
        0 => '',
      ),
      '%s not found.' => 
      array (
        0 => '%s est introuvable.',
      ),
      'Logged in successfully.' => 
      array (
        0 => 'Connecté avec succès.',
      ),
      'Changes saved.' => 
      array (
        0 => 'Modifications enregistrées.',
      ),
      'Clone Station: %s' => 
      array (
        0 => 'Clone de la station : %s',
      ),
      'SHOUTcast version "%s" is currently installed.' => 
      array (
        0 => '',
      ),
      'Install SHOUTcast' => 
      array (
        0 => 'Installer SHOUTcast',
      ),
      'API Key' => 
      array (
        0 => 'Clé API',
      ),
      'Sync Task Output' => 
      array (
        0 => 'Synchronisation de sortie de tâche',
      ),
      'Permission' => 
      array (
        0 => 'Permissions',
      ),
      'System Settings' => 
      array (
        0 => 'Configuration système',
      ),
      'Path "%s" is not a folder.' => 
      array (
        0 => 'Le chemin "%s" n\'est pas un dossier.',
      ),
      'Could not move "%s" to "%s"' => 
      array (
        0 => 'Impossible de déplacer "%s" vers "%s"',
      ),
      'Directory' => 
      array (
        0 => 'Annuaire',
      ),
      'File Not Processed' => 
      array (
        0 => 'Fichier non traité',
      ),
      'File renamed!' => 
      array (
        0 => 'Fichier renommé !',
      ),
      'Rename File/Directory' => 
      array (
        0 => 'Renommer le fichier/répertoire',
      ),
      'This station is out of available storage space.' => 
      array (
        0 => '',
      ),
      'Mount Point' => 
      array (
        0 => 'Point de montage',
      ),
      'Streamers enabled!' => 
      array (
        0 => 'Streamers activés !',
      ),
      'You can now set up streamer (DJ) accounts.' => 
      array (
        0 => 'Vous pouvez maintenant configurer des comptes pour les streamers (DJs).',
      ),
      'Streamer' => 
      array (
        0 => 'Streamer',
      ),
      'Remote Relay' => 
      array (
        0 => 'Relais distant',
      ),
      'SoundExchange Report' => 
      array (
        0 => 'Rapport SoundExchange',
      ),
      'Web Hook' => 
      array (
        0 => 'Web Hook',
      ),
      '%s enabled.' => 
      array (
        0 => '%s est activé.',
      ),
      '%s disabled.' => 
      array (
        0 => '%s est désactivé.',
      ),
      'Web Hook Test Output' => 
      array (
        0 => 'Tester la Web Hook',
      ),
      'Automated assignment complete!' => 
      array (
        0 => 'Affectation automatique complété !',
      ),
      'Automated assignment error' => 
      array (
        0 => 'Erreur lors de l\'affectation automatique',
      ),
      'This playlist is not a sequential playlist.' => 
      array (
        0 => 'Cette playlist n’est pas une playlist séquentielle.',
      ),
      'Format' => 
      array (
        0 => 'Format',
      ),
      'Playlist enabled.' => 
      array (
        0 => '',
      ),
      'Playlist disabled.' => 
      array (
        0 => '',
      ),
      'Existing playlist imported.' => 
      array (
        0 => 'Playlist existante importée.',
      ),
      '%d song(s) were imported into the playlist.' => 
      array (
        0 => '%d titres(s) ont été importés dans la playlist.',
      ),
      'Playlist' => 
      array (
        0 => 'Playlist',
      ),
      'Song Title' => 
      array (
        0 => 'Titre de la musique',
      ),
      'Song Artist' => 
      array (
        0 => 'Artiste de la musique',
      ),
      'Too many login attempts' => 
      array (
        0 => 'Trop de tentatives de connexion',
      ),
      'You have attempted to log in too many times. Please wait 30 seconds and try again.' => 
      array (
        0 => 'Tentatives de connexion trop nombreuses. Veuillez essayer de nouveau dans 30 secondes.',
      ),
      'Login unsuccessful' => 
      array (
        0 => 'Échec de connexion',
      ),
      'Your credentials could not be verified.' => 
      array (
        0 => 'Vos informations d\'identification n\'ont pas pu être vérifiées.',
      ),
      'Setup has already been completed!' => 
      array (
        0 => 'L\'installation est déjà terminée !',
      ),
      'Super Administrator' => 
      array (
        0 => 'Super administrateur',
      ),
      'Want to use SHOUTcast 2? <a href="%s" target="_blank">Install it here</a>, then reload this page.' => 
      array (
        0 => 'Vous souhaitez utiliser SHOUTcast 2 ? <a href="%s" target="_blank">Installez-le ici</a>, ensuite recharger la page.',
      ),
      'Setup is now complete!' => 
      array (
        0 => 'L\'installation s\'est terminée !',
      ),
      'Continue setting up your station in the main AzuraCast app.' => 
      array (
        0 => 'Poursuivez la configuration de votre station dans l’application principale d\'AzuraCast.',
      ),
      '%s Listener Range' => 
      array (
        0 => 'Rangée d\'auditeurs %s',
      ),
      '%s Daily Average' => 
      array (
        0 => 'Moyenne journalière %s',
      ),
      'Profile saved!' => 
      array (
        0 => 'Profil enregistré !',
      ),
      'Edit Profile' => 
      array (
        0 => 'Modifier le profil',
      ),
      'The token you supplied is invalid. Please try again.' => 
      array (
        0 => '',
      ),
      'Two-factor authentication enabled.' => 
      array (
        0 => '',
      ),
      'Two-factor authentication disabled.' => 
      array (
        0 => '',
      ),
      'Start Station' => 
      array (
        0 => '',
      ),
      'Ready to start broadcasting? Click to start your station.' => 
      array (
        0 => '',
      ),
      'Restart to Apply Changes' => 
      array (
        0 => '',
      ),
      'Click to restart your station and apply configuration changes.' => 
      array (
        0 => '',
      ),
      'Public Page' => 
      array (
        0 => 'Page publique',
      ),
      'Music Files' => 
      array (
        0 => 'Fichiers musicaux',
      ),
      'Playlists' => 
      array (
        0 => 'Playlists',
      ),
      'Streamer/DJ Accounts' => 
      array (
        0 => 'Comptes des streamers/DJs',
      ),
      'Web DJ' => 
      array (
        0 => '',
      ),
      'Reports' => 
      array (
        0 => 'Rapports',
      ),
      'Statistics Overview' => 
      array (
        0 => '',
      ),
      'Listeners' => 
      array (
        0 => 'Auditeurs',
      ),
      'Song Requests' => 
      array (
        0 => 'Demandes de titres',
      ),
      'Song Playback Timeline' => 
      array (
        0 => 'Historique des titres',
      ),
      'Song Listener Impact' => 
      array (
        0 => 'Impact sur le nombre d\'auditeurs',
      ),
      'Duplicate Songs' => 
      array (
        0 => 'Titres à double',
      ),
      'SoundExchange Royalties' => 
      array (
        0 => '',
      ),
      'Utilities' => 
      array (
        0 => 'Utilitaires',
      ),
      'Automated Assignment' => 
      array (
        0 => 'Affectation automatique',
      ),
      'Log Viewer' => 
      array (
        0 => '',
      ),
      'Upcoming Song Queue' => 
      array (
        0 => '',
      ),
      'Restart Broadcasting' => 
      array (
        0 => 'Redémarrer la diffusion',
      ),
      'System Maintenance' => 
      array (
        0 => 'Maintenance système',
      ),
      'Custom Branding' => 
      array (
        0 => '',
      ),
      'System Logs' => 
      array (
        0 => '',
      ),
      'User Accounts' => 
      array (
        0 => 'Comptes utilisateurs',
      ),
      'Generic Web Hook' => 
      array (
        0 => '',
      ),
      'Automatically send a message to any URL when your station data changes.' => 
      array (
        0 => '',
      ),
      'TuneIn AIR' => 
      array (
        0 => '',
      ),
      'Send song metadata changes to TuneIn.' => 
      array (
        0 => '',
      ),
      'Discord Webhook' => 
      array (
        0 => '',
      ),
      'Automatically send a customized message to your Discord server.' => 
      array (
        0 => '',
      ),
      'Telegram Chat Message' => 
      array (
        0 => '',
      ),
      'Use the Telegram Bot API to send a message to a channel.' => 
      array (
        0 => '',
      ),
      'Twitter Post' => 
      array (
        0 => '',
      ),
      'Automatically send a tweet.' => 
      array (
        0 => '',
      ),
      'Any time the currently playing song changes' => 
      array (
        0 => '',
      ),
      'Any time the listener count increases' => 
      array (
        0 => '',
      ),
      'Any time the listener count decreases' => 
      array (
        0 => '',
      ),
      'Any time a live streamer/DJ connects to the stream' => 
      array (
        0 => '',
      ),
      'Any time a live streamer/DJ disconnects from the stream' => 
      array (
        0 => '',
      ),
      'Mount Point URL' => 
      array (
        0 => '',
      ),
      'This name should always begin with a slash (/), and must be a valid URL, such as /autodj.mp3' => 
      array (
        0 => 'Ce nom doit toujours commencer par un slash (/) et doit être une URL valide, par exemple /autodj.mp3',
      ),
      'Display Name' => 
      array (
        0 => '',
      ),
      'The display name assigned to this mount point when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => '',
      ),
      'Show on Public Pages' => 
      array (
        0 => '',
      ),
      'Enable to allow listeners to select this mount point on this station\'s public pages.' => 
      array (
        0 => '',
      ),
      'Yes' => 
      array (
        0 => 'Oui',
      ),
      'No' => 
      array (
        0 => 'Non',
      ),
      'Set as Default Mount Point' => 
      array (
        0 => '',
      ),
      'If this mount is the default, it will be played on the radio preview and the public radio page in this system.' => 
      array (
        0 => 'Si ce point de montage est celui par défaut, il sera lu en premier sur l\'aperçu de la station et sur la page publique du système.',
      ),
      'Relay Stream URL' => 
      array (
        0 => 'URL du flux a relayer',
      ),
      'Enter the full URL of another stream to relay its broadcast through this mount point.' => 
      array (
        0 => 'Entrez l’URL complète d’un autre flux pour relayer sa diffusion par le biais de ce point de montage.',
      ),
      'Publish to "Yellow Pages" Directories' => 
      array (
        0 => '',
      ),
      'Enable to advertise this mount point on "Yellow Pages" public radio directories.' => 
      array (
        0 => '',
      ),
      'Enable AutoDJ' => 
      array (
        0 => 'Activer l\'AutoDJ',
      ),
      'If enabled, the AutoDJ will automatically play music to this mount point.' => 
      array (
        0 => '',
      ),
      'Configure AutoDJ Broadcasting' => 
      array (
        0 => '',
      ),
      'AutoDJ Format' => 
      array (
        0 => 'Format de l\'AutoDJ',
      ),
      'AutoDJ Bitrate (kbps)' => 
      array (
        0 => 'Taux de l\'AutoDJ (Kb/s)',
      ),
      'Advanced Configuration' => 
      array (
        0 => '',
      ),
      'Custom Stream URL' => 
      array (
        0 => '',
      ),
      'You can set a custom URL for this stream that AzuraCast will use when referring to it. Leave empty to use the default value.' => 
      array (
        0 => '',
      ),
      'Save Changes' => 
      array (
        0 => 'Sauvegarder',
      ),
      'Fallback Mount' => 
      array (
        0 => 'Point de montage de secours',
      ),
      'If this mount point is not playing audio, listeners will automatically be redirected to this mount point. The default is /error.mp3, a repeating error message.' => 
      array (
        0 => 'Si ce point de montage ne joue plus d\'audio, les auditeurs seront redirigés automatiquement vers ce point. Par défaut /error.mp3, un message d\'erreur, sera lu.',
      ),
      'Custom Frontend Configuration' => 
      array (
        0 => '',
      ),
      'You can include any special mount point settings here, in either JSON { key: \'value\' } format or XML &lt;key&gt;value&lt;/key&gt;' => 
      array (
        0 => 'Vous pouvez inclure des paramètres spéciaux pour ce point de montage, au format JSON { key: \'value\' } ou au format XML &lt;key&gt;value&lt;/key&gt;',
      ),
      'Stream path cannot include reserved keywords: %s' => 
      array (
        0 => '',
      ),
      'YP Directory Authorization Hash' => 
      array (
        0 => '',
      ),
      'If your stream is set to advertise to YP directories above, you must specify an authorization hash. You can manage authhashes <a href="%s" target="_blank">on the SHOUTcast web site</a>.' => 
      array (
        0 => '',
      ),
      'New Station Details' => 
      array (
        0 => 'Détails de la nouvelle station',
      ),
      'Station Name' => 
      array (
        0 => 'Nom de la station',
      ),
      'Station Description' => 
      array (
        0 => 'Description de la station',
      ),
      'Customize Station Cloning' => 
      array (
        0 => 'Personnalisation du clonage de la station',
      ),
      'Copy Media?' => 
      array (
        0 => 'Copier les médias ?',
      ),
      'Choose how media should be duplicated from the old station.' => 
      array (
        0 => 'Choisissez comment les médias doivent être dupliqués de l\'ancienne station.',
      ),
      'Do not share or copy media between the stations' => 
      array (
        0 => 'Ne pas partager ou copier les médias entre les stations',
      ),
      'Share the same folder on disk between the stations' => 
      array (
        0 => 'Partager le même dossier sur le disque entre les stations',
      ),
      'Copy the existing station\'s media to the new station' => 
      array (
        0 => 'Copier les médias de la station existante vers la nouvelle station',
      ),
      'Copy Playlists?' => 
      array (
        0 => 'Copier les playlists ?',
      ),
      'Copy Streamer/DJ Accounts?' => 
      array (
        0 => 'Copier les comptes des streamers / DJs ?',
      ),
      'Copy Permissions?' => 
      array (
        0 => 'Copier les permissions ?',
      ),
      'Selecting "Yes" will assign any users with permissions to the current station to have permissions to the new one.' => 
      array (
        0 => 'Sélectionner "Oui" va assigner à tous les utilisateurs qui ont accès à cette station les mêmes permissions vers la nouvelle station.',
      ),
      'Create New Station' => 
      array (
        0 => 'Créer une nouvelle station',
      ),
      'Field Name' => 
      array (
        0 => 'Nom du champ',
      ),
      'This will be used as the label when editing individual songs, and will show in API results.' => 
      array (
        0 => '',
      ),
      'Programmatic Name' => 
      array (
        0 => '',
      ),
      'Optionally specify an API-friendly name, such as <code>field_name</code>. Leave this field blank to automatically create one based on the name.' => 
      array (
        0 => '',
      ),
      'Important Notes' => 
      array (
        0 => 'Notes Importantes',
      ),
      '<p>SHOUTcast 2 DNAS is not free software, and its restrictive license does not allow AzuraCast to distribute the SHOUTcast binary. In order to install SHOUTcast, you should download the Linux x64 binary from the <a href="%s" target="_blank">SHOUTcast Radio Manager</a> web site. Upload the <code>sc_serv2_linux_x64-latest.tar.gz</code> into the field below to automatically extract it into the proper directory.</p>' => 
      array (
        0 => '',
      ),
      'Current Installed Version' => 
      array (
        0 => '',
      ),
      'SHOUTcast is not currently installed on this installation.' => 
      array (
        0 => '',
      ),
      'Select SHOUTcast 64-bit .tar.gz File' => 
      array (
        0 => 'Sélectionner le fichier SHOUTcast 64bits. tar.gz',
      ),
      'Upload' => 
      array (
        0 => 'Envoyer',
      ),
      'E-mail Address' => 
      array (
        0 => 'Adresse e-mail',
      ),
      'Password' => 
      array (
        0 => 'Mot de passe',
      ),
      'Log in' => 
      array (
        0 => 'Se connecter',
      ),
      'Your current local time is <b>%s</b> (%s UTC). You can customize your time zone from the "My Account" page.' => 
      array (
        0 => '',
      ),
      'Basic Information' => 
      array (
        0 => '',
      ),
      'Playlist Name' => 
      array (
        0 => 'Nom de la playlist',
      ),
      'Enable Playlist' => 
      array (
        0 => 'Activez la playlist',
      ),
      'If set to "No", the playlist will not be included in radio playback, but can still be managed.' => 
      array (
        0 => 'Si la valeur est « Non », la playlist ne sera pas ajoutée dans la liste de lecture de la station, mais pourra toujours être gérée.',
      ),
      'Playlist Weight' => 
      array (
        0 => 'Priorité de la playlist',
      ),
      'Higher weight playlists are played more frequently compared to other lower-weight playlists.' => 
      array (
        0 => 'Les playlists aux priorités plus élevées joueront plus régulièrement que celle aux priorités plus basse.',
      ),
      'Low' => 
      array (
        0 => 'Faible',
      ),
      'Default' => 
      array (
        0 => 'Par défaut',
      ),
      'High' => 
      array (
        0 => 'Élevée',
      ),
      'Source' => 
      array (
        0 => 'Source',
      ),
      'Song-Based Playlist' => 
      array (
        0 => '',
      ),
      'A playlist containing media files hosted on this server.' => 
      array (
        0 => '',
      ),
      'Remote URL Playlist' => 
      array (
        0 => '',
      ),
      'A playlist that instructs the station to play from a remote URL.' => 
      array (
        0 => '',
      ),
      'Song Playback Order' => 
      array (
        0 => '',
      ),
      'Shuffled' => 
      array (
        0 => 'Aléatoire',
      ),
      'Random' => 
      array (
        0 => 'Au hasard',
      ),
      'Sequential' => 
      array (
        0 => 'Séquentiel',
      ),
      'Hide Metadata from Listeners ("Jingle Mode")' => 
      array (
        0 => '',
      ),
      'Enable this setting to prevent metadata from being sent to the AutoDJ for files in this playlist. This is useful if the playlist contains jingles or bumpers.' => 
      array (
        0 => '',
      ),
      'Allow Requests from This Playlist' => 
      array (
        0 => '',
      ),
      'If requests are enabled for your station, users will be able to request media that is on this playlist.' => 
      array (
        0 => '',
      ),
      'Import Existing Playlist' => 
      array (
        0 => 'Importer une playlist existante',
      ),
      'Select an existing playlist file to add its contents to this playlist. PLS and M3U are supported.' => 
      array (
        0 => 'Sélectionnez un fichier de playlist existant pour ajouter son contenu à cette liste de lecture. PLS et M3U sont pris en charge.',
      ),
      'Remote URL' => 
      array (
        0 => 'URL distante',
      ),
      'Remote URL Type' => 
      array (
        0 => '',
      ),
      'Direct Stream URL' => 
      array (
        0 => '',
      ),
      'Playlist (M3U/PLS) URL' => 
      array (
        0 => '',
      ),
      'Scheduling' => 
      array (
        0 => '',
      ),
      'General Rotation' => 
      array (
        0 => '',
      ),
      'Plays all day, shuffles with other standard playlists based on weight.' => 
      array (
        0 => 'Joue toute la journée, mélangée avec d’autres playlists basées sur leurs priorités.',
      ),
      'Scheduled' => 
      array (
        0 => '',
      ),
      'Play during a scheduled time range. Useful for mood-based time playlists.' => 
      array (
        0 => 'Jouer pendant un intervalle de temps. Utile pour les playlists axées sur les heures de la journée.',
      ),
      'Once per x Songs' => 
      array (
        0 => '',
      ),
      'Play exactly once every <i>x</i> songs. Useful for station ID/jingles.' => 
      array (
        0 => 'Jouer exactement une fois après <i>x</i> titres. Utile pour les ID/jingles.',
      ),
      'Once Per x Minutes' => 
      array (
        0 => '',
      ),
      'Play exactly once every <i>x</i> minutes. Useful for station ID/jingles.' => 
      array (
        0 => 'Jouer exactement une fois après <i>x</i> minutes. Utile pour les ID/jingles.',
      ),
      'Daily' => 
      array (
        0 => '',
      ),
      'Play once per day at the specified time. Useful for timely reminders.' => 
      array (
        0 => 'Jouer une fois par jour à l’heure indiquée. Pratique pour les top horaires.',
      ),
      'Advanced' => 
      array (
        0 => '',
      ),
      'Manually define how this playlist is used in Liquidsoap configuration. <a href="%s" target="_blank">Learn about Advanced Playlists</a>' => 
      array (
        0 => '',
      ),
      'Include in Automated Assignment' => 
      array (
        0 => 'Inclure dans l\'affectation automatique',
      ),
      'If auto-assignment is enabled, use this playlist as one of the targets for songs to be redistributed into. This will overwrite the existing contents of this playlist.' => 
      array (
        0 => 'Si l\'Affectation Automatique est activée, cette playlist sera l\'une des destinations en cas de redistribution des titres. Ceci va écraser le contenu de cette playlist.',
      ),
      'Customize Schedule' => 
      array (
        0 => '',
      ),
      'Start Time' => 
      array (
        0 => 'Heure de début',
      ),
      'End Time' => 
      array (
        0 => 'Heure de fin',
      ),
      'If the end time is before the start time, the playlist will play overnight until this time on the next day.' => 
      array (
        0 => 'Si l’heure de fin est avant l’heure de début, la playlist jouera durant la nuit jusqu\'au jour suivant.',
      ),
      'Scheduled Play Days of Week' => 
      array (
        0 => '',
      ),
      'Leave blank to play on every day of the week.' => 
      array (
        0 => '',
      ),
      'Monday' => 
      array (
        0 => 'Lundi',
      ),
      'Tuesday' => 
      array (
        0 => 'Mardi',
      ),
      'Wednesday' => 
      array (
        0 => 'Mercredi',
      ),
      'Thursday' => 
      array (
        0 => 'Jeudi',
      ),
      'Friday' => 
      array (
        0 => 'Vendredi',
      ),
      'Saturday' => 
      array (
        0 => 'Samedi',
      ),
      'Sunday' => 
      array (
        0 => 'Dimanche',
      ),
      'Number of Songs Between Plays' => 
      array (
        0 => 'Nombre de musiques entre chaque lectures',
      ),
      'This playlist will play every $x songs, where $x is specified below.' => 
      array (
        0 => 'Cette playlist jouera chaque $x titres, où $x est indiqué ci-dessous.',
      ),
      'Once per x Minutes' => 
      array (
        0 => 'Une fois chaque x minutes',
      ),
      'Number of Minutes Between Plays' => 
      array (
        0 => 'Nombre de minutes entre chaque lecture',
      ),
      'This playlist will play every $x minutes, where $x is specified below.' => 
      array (
        0 => 'Cette playlist jouera chaque $x minutes, où $x est indiqué ci-dessous.',
      ),
      'Scheduled Play Time' => 
      array (
        0 => 'Lecture programmée',
      ),
      'Comments' => 
      array (
        0 => 'Commentaires',
      ),
      'Describe the use-case for this API key for future reference.' => 
      array (
        0 => '',
      ),
      'This report is intended for licensing in the United States only, for webcasters paying royalties via SoundExchange. Learn more about the requirements for reporting and classification on the <a href="%s" target="_blank">SoundExchange web site</a>.' => 
      array (
        0 => '',
      ),
      'AzuraCast assumes that your station fits SoundExchange Transmission Category A, "Eligible nonsubscription transmissions other than broadcast simulcasts and transmissions of non-music programming." If your station does not fall within this category, update the transmission category field accordingly.' => 
      array (
        0 => '',
      ),
      'The data collected by AzuraCast meets the SoundExchange standard for Actual Total Performances (ATP) by tracking unique listeners across all song plays. All other information is derived from the metadata of the uploaded songs themselves, and may not be completely accurate.' => 
      array (
        0 => '',
      ),
      'Reporting requirements for SoundExchange may change at any time. AzuraCast is non-commercial community-built software and cannot guarantee that its reporting format will always be up-to-date.' => 
      array (
        0 => '',
      ),
      'You should always verify the report generated by AzuraCast before sending it. In particular, either the ISRC (International Standard Recording Code) or *both* the album and label are required for every row, and may not be provided in the song metadata. AzuraCast will use external APIs to try to find the ISRC, but you can also use <a href="%s" target="_blank">SoundExchange\'s ISRC search tool</a>.' => 
      array (
        0 => '',
      ),
      'Report Start Date' => 
      array (
        0 => 'Date de début du rapport',
      ),
      'Report End Date' => 
      array (
        0 => 'Date de fin du rapport',
      ),
      'Generate Report' => 
      array (
        0 => 'Générer le rapport',
      ),
      'Code from Authenticator App' => 
      array (
        0 => '',
      ),
      'Enter the current code provided by your authenticator app to verify that it\'s working correctly.' => 
      array (
        0 => '',
      ),
      'Verify Authenticator' => 
      array (
        0 => '',
      ),
      'Role Name' => 
      array (
        0 => 'Nom du rôle',
      ),
      'System-Wide Permissions' => 
      array (
        0 => 'Permissions globales',
      ),
      'Permissions for %s' => 
      array (
        0 => '',
      ),
      'File Name' => 
      array (
        0 => 'Nom du Fichier',
      ),
      'The relative path of the file in the station\'s media directory.' => 
      array (
        0 => 'Le chemin relatif dans le répertoire des médias, pour cette station.',
      ),
      'Site Base URL' => 
      array (
        0 => 'URL de base du site',
      ),
      'The base URL where this service is located. Use either the external IP address or fully-qualified domain name (if one exists) pointing to this server.' => 
      array (
        0 => 'L\'URL de base où se trouve ce service. Utilisez soit l\'IP externe, soit un nom de domaine complet (le cas échéant) pointant vers ce serveur.',
      ),
      'AzuraCast Instance Name' => 
      array (
        0 => 'Nom de l\'instance AzuraCast',
      ),
      'This name will appear as a sub-header next to the AzuraCast logo, to help identify this server.' => 
      array (
        0 => 'Ce nom va apparaître comme sous-titre à côté du logo d\'AzuraCast, pour vous aider à identifier ce serveur.',
      ),
      'System Default Time Zone' => 
      array (
        0 => '',
      ),
      'For users who have not customized their time zone, all times displayed on the site will be based on this time zone.' => 
      array (
        0 => '',
      ),
      'Prefer Browser URL (If Available)' => 
      array (
        0 => '',
      ),
      'If this setting is set to "Yes", the browser URL will be used instead of the base URL when it\'s available. Set to "No" to always use the base URL.' => 
      array (
        0 => '',
      ),
      'Use Web Proxy for Radio' => 
      array (
        0 => 'Utiliser un Proxy Web pour la station',
      ),
      'By default, radio stations broadcast on their own ports (i.e. 8000). If you\'re using a service like CloudFlare or accessing your radio station by SSL, you should enable this feature, which routes all radio through the web ports (80 and 443).' => 
      array (
        0 => 'Par défaut, les stations diffusent sur leurs propres port (par ex. 8000). Si vous utilisez un service comme CloudFlare ou que vous accédez à votre radio via SSL, vous devriez activer cette fonctionnalité qui dirigera la radio à travers les ports web (80 et 443).',
      ),
      'Days of Playback History to Keep' => 
      array (
        0 => '',
      ),
      'Set longer to preserve more playback history for stations. Set shorter to save disk space.' => 
      array (
        0 => '',
      ),
      'Last 14 Days' => 
      array (
        0 => '14 derniers jours',
      ),
      'Last 30 Days' => 
      array (
        0 => '30 derniers jours',
      ),
      'Last 60 Days' => 
      array (
        0 => '60 derniers jours',
      ),
      'Last Year' => 
      array (
        0 => 'L’an dernier',
      ),
      'Last 2 Years' => 
      array (
        0 => 'Il y a deux ans',
      ),
      'Indefinitely' => 
      array (
        0 => 'Indéfiniment',
      ),
      'Security Controls' => 
      array (
        0 => '',
      ),
      'Always Use HTTPS' => 
      array (
        0 => 'Toujours utiliser HTTPS',
      ),
      'Set to "Yes" to always use "https://" secure URLs, and to automatically redirect to the secure URL when an insecure URL is visited.' => 
      array (
        0 => '',
      ),
      'API "Access-Control-Allow-Origin" header' => 
      array (
        0 => '',
      ),
      '<a href="%s" target="_blank">Learn more about this header</a>. Set to * to allow all sources, or specify a list of origins separated by a comma (,).' => 
      array (
        0 => '',
      ),
      'Privacy Controls' => 
      array (
        0 => '',
      ),
      'AzuraCast does not send your station or listener data to any external server. You can control how much data AzuraCast logs about your listeners here.' => 
      array (
        0 => '',
      ),
      'Listener Analytics Collection' => 
      array (
        0 => '',
      ),
      'Aggregate listener statistics are used to show station reports across the system. IP-based listener statistics are used to view live listener tracking and may be required for royalty reports.' => 
      array (
        0 => '',
      ),
      '<b>Full:</b> Collect aggregate listener statistics and IP-based listener statistics' => 
      array (
        0 => '',
      ),
      '<b>Limited:</b> Only collect aggregate listener statistics' => 
      array (
        0 => '',
      ),
      '<b>None:</b> Do not collect any listener analytics' => 
      array (
        0 => '',
      ),
      'AzuraCast Installation Telemetry' => 
      array (
        0 => '',
      ),
      'Choose whether your installation communicates with central AzuraCast servers to check for updates and announcements.<br>AzuraCast respects your privacy; see our <a href="%s" target="_blank">privacy policy</a> for more details.' => 
      array (
        0 => '',
      ),
      'Check for Updates and Announcements' => 
      array (
        0 => '',
      ),
      'Send minimal details about your AzuraCast installation to the AzuraCast central server to check for updated software releases and important announcements.' => 
      array (
        0 => '',
      ),
      '<b>None:</b> Do not check for updates or announcements.' => 
      array (
        0 => '',
      ),
      '<b>Release Only:</b> Critical announcements and new release versions only.' => 
      array (
        0 => '',
      ),
      '<b>All Updates:</b> Include all announcements and minor updates.' => 
      array (
        0 => '',
      ),
      'Automatically Send Error Reports to AzuraCast' => 
      array (
        0 => '',
      ),
      'If the web application encounters an error, you can choose to automatically send an anonymized report of the error to the AzuraCast team for faster diagnosis and resolution.' => 
      array (
        0 => '',
      ),
      'Error reports are powered by <a href="%s" target="_blank">%s</a>.' => 
      array (
        0 => '',
      ),
      'Enable Automated Assignment' => 
      array (
        0 => 'Activer l’affectation automatique',
      ),
      'Allow the system to periodically automatically assign songs to playlists based on their performance. This process will run in the background, and will only run if this option is set to "Enabled" and at least one playlist is set to "Include in Automated Assignment".' => 
      array (
        0 => 'Laissez le système affecter automatiquement et périodiquement les titres a des playlists, basées sur leurs performances. Ce processus s’exécute en arrière-plan et ne fonctionnera que si cette option est définie sur « Activé » et au moins une liste de lecture est définie à « Inclure dans l’Affectation Automatique ».',
      ),
      'Disabled' => 
      array (
        0 => 'Désactivé',
      ),
      'Enabled' => 
      array (
        0 => 'Activé',
      ),
      'Days Between Automated Assignments' => 
      array (
        0 => 'Jours entre chaque affectations automatiques',
      ),
      'Based on this setting, the system will automatically reassign songs every (this) days using data from the previous (this) days.' => 
      array (
        0 => 'Basé sur ce paramètre, le système assignera automatiquement les titres chaque (X) jours, à l’aide des données provenant des derniers (X) jours.',
      ),
      '%d days' => 
      array (
        0 => '%d jours',
      ),
      'Name' => 
      array (
        0 => 'Nom',
      ),
      'Reset Password' => 
      array (
        0 => 'Réinitialiser le mot de passe',
      ),
      'Leave blank to use the current password.' => 
      array (
        0 => 'Laissez vide pour garder le mot de passe actuel.',
      ),
      'Roles' => 
      array (
        0 => 'Rôles',
      ),
      'Use Browser Default' => 
      array (
        0 => 'Utiliser la valeur du navigateur',
      ),
      'Account Information' => 
      array (
        0 => 'Informations du compte',
      ),
      'Leave these fields blank to continue using your current password.' => 
      array (
        0 => '',
      ),
      'Current Password' => 
      array (
        0 => '',
      ),
      'New Password' => 
      array (
        0 => '',
      ),
      'Confirm New Password' => 
      array (
        0 => '',
      ),
      'Customization' => 
      array (
        0 => 'Personnalisation',
      ),
      'Time Zone' => 
      array (
        0 => 'Fuseau horaire',
      ),
      'All times displayed on the site will be based on this time zone.' => 
      array (
        0 => 'Toutes les heures affichées sur le site s’appuieront sur ce fuseau horaire.',
      ),
      'Current server time is <b>%s</b>.' => 
      array (
        0 => 'L\'heure et la date actuelle du serveur est <b>%s</b>.',
      ),
      'Language' => 
      array (
        0 => 'Langue',
      ),
      'Site Theme' => 
      array (
        0 => 'Thème du site',
      ),
      'Light' => 
      array (
        0 => 'Clair',
      ),
      'Dark' => 
      array (
        0 => 'Sombre',
      ),
      'Base Theme for Public Pages' => 
      array (
        0 => 'Thème de base pour les pages publiques',
      ),
      'Select a theme to use as a base for station public pages and the login page.' => 
      array (
        0 => 'Sélectionnez un thème à utiliser comme base pour les pages publiques de la station et la page de connexion.',
      ),
      'Hide Album Art on Public Pages' => 
      array (
        0 => 'Masquer les pochettes d\'album sur les pages publiques',
      ),
      'If selected, album art will not display on public-facing radio pages.' => 
      array (
        0 => '',
      ),
      'Homepage Redirect URL' => 
      array (
        0 => '',
      ),
      'If a visitor is not signed in and visits the AzuraCast homepage, you can automatically redirect them to the URL specified here. Leave blank to redirect them to the login screen by default.' => 
      array (
        0 => '',
      ),
      'Default Album Art URL' => 
      array (
        0 => '',
      ),
      'If a song has no album art, this URL will be listed instead. Leave blank to use the standard placeholder art.' => 
      array (
        0 => '',
      ),
      'Hide AzuraCast Branding on Public Pages' => 
      array (
        0 => '',
      ),
      'If selected, this will remove the AzuraCast branding from public-facing pages.' => 
      array (
        0 => '',
      ),
      'Custom CSS for Public Pages' => 
      array (
        0 => 'CSS personnalisé pour les pages publique',
      ),
      'This CSS will be applied to the station public pages and login page.' => 
      array (
        0 => 'Ce CSS sera appliqué aux pages publiques de la station et à la page de connexion.',
      ),
      'Custom JS for Public Pages' => 
      array (
        0 => 'JS personnalisé pour les pages publique',
      ),
      'This javascript code will be applied to the station public pages and login page.' => 
      array (
        0 => 'Ce code javascript sera appliqué aux pages publiques de la station et à la page de connexion.',
      ),
      'Custom CSS for Internal Pages' => 
      array (
        0 => 'CSS personnalisé pour les pages internes',
      ),
      'This CSS will be applied to the main management pages, like this one.' => 
      array (
        0 => 'Ce CSS sera appliqué aux pages de gestion, comme celle-ci.',
      ),
      'Telegram API Details' => 
      array (
        0 => '',
      ),
      '%s Name' => 
      array (
        0 => '',
      ),
      'Choose a name for this webhook that will help you distinguish it from others. This will only be shown on the administration page.' => 
      array (
        0 => '',
      ),
      'Bot Token' => 
      array (
        0 => '',
      ),
      'See the <a href="%s" target="_blank">Telegram Documentation</a> for more details.' => 
      array (
        0 => '',
      ),
      'Chat ID' => 
      array (
        0 => '',
      ),
      'Unique identifier for the target chat or username of the target channel (in the format @channelusername).' => 
      array (
        0 => '',
      ),
      'Custom API Base URL' => 
      array (
        0 => '',
      ),
      'Leave blank to use the default Telegram API URL (recommended). Specify the full URL, like <code>https://api.pwrtelegram.xyz/</code>.' => 
      array (
        0 => '',
      ),
      'Web Hook Triggers' => 
      array (
        0 => '',
      ),
      'Customize Message' => 
      array (
        0 => '',
      ),
      'Variables are in the form of <code>{{ var.name }}</code>. All values in the <a href="%s" target="_blank">Now Playing API response</a> are avaliable for use. Any empty fields are ignored.' => 
      array (
        0 => '',
      ),
      'Main Message Content' => 
      array (
        0 => '',
      ),
      'Now playing on %s: %s by %s! Tune in now.' => 
      array (
        0 => '',
      ),
      'Message parsing mode' => 
      array (
        0 => '',
      ),
      'Twitter Account Details' => 
      array (
        0 => '',
      ),
      'Steps for configuring a Twitter application:<br>
                <ol type="1">
                    <li>Create a new app on the <a href="%s" target="_blank">Twitter Applications site</a>. 
                    Use this installation\'s base URL as the application URL.</li>
                    <li>In the newly created application, click the "Keys and Access Tokens" tab.</li>
                    <li>At the bottom of the page, click "Create my access token".</li>
                </ol>
                Once these steps are completed, enter the information from the "Keys and Access Tokens" page into the fields below.' => 
      array (
        0 => '',
      ),
      'Consumer Key (API Key)' => 
      array (
        0 => '',
      ),
      'Consumer Secret (API Secret)' => 
      array (
        0 => '',
      ),
      'Access Token' => 
      array (
        0 => '',
      ),
      'Access Token Secret' => 
      array (
        0 => '',
      ),
      'Only Send One Tweet Every...' => 
      array (
        0 => '',
      ),
      'No Limit' => 
      array (
        0 => '',
      ),
      'Web Hook Details' => 
      array (
        0 => '',
      ),
      'Message Body' => 
      array (
        0 => '',
      ),
      'Web hooks automatically send a HTTP POST request to the URL you specify to 
                notify it any time one of the triggers you specify occurs on your station. The body of the POST message
                is the exact same as the <a href="%s" target="_blank">Now Playing API response</a> for your station. 
                In order to process quickly, web hooks have a short timeout, so the responding service should be
                optimized to handle the request in under 2 seconds.' => 
      array (
        0 => '',
      ),
      'Web Hook URL' => 
      array (
        0 => '',
      ),
      'The URL that will receive the POST messages any time an event is triggered.' => 
      array (
        0 => '',
      ),
      'Optional: HTTP Basic Authentication Username' => 
      array (
        0 => '',
      ),
      'If your web hook requires HTTP basic authentication, provide the username here.' => 
      array (
        0 => '',
      ),
      'Optional: HTTP Basic Authentication Password' => 
      array (
        0 => '',
      ),
      'If your web hook requires HTTP basic authentication, provide the password here.' => 
      array (
        0 => '',
      ),
      'TuneIn Partner ID' => 
      array (
        0 => '',
      ),
      'TuneIn Partner Key' => 
      array (
        0 => '',
      ),
      'TuneIn Station ID' => 
      array (
        0 => '',
      ),
      'The station ID will be a numeric string that starts with the letter S.' => 
      array (
        0 => '',
      ),
      'Discord API Details' => 
      array (
        0 => '',
      ),
      'Discord Web Hook URL' => 
      array (
        0 => '',
      ),
      'This URL is provided within the Discord application.' => 
      array (
        0 => '',
      ),
      'Now playing on %s:' => 
      array (
        0 => '',
      ),
      'Title' => 
      array (
        0 => 'Titre',
      ),
      'Description' => 
      array (
        0 => 'Description',
      ),
      'URL' => 
      array (
        0 => '',
      ),
      'Author Name' => 
      array (
        0 => 'Nom de l\'auteur',
      ),
      'Thumbnail Image URL' => 
      array (
        0 => '',
      ),
      'Footer Text' => 
      array (
        0 => '',
      ),
      'Powered by %s' => 
      array (
        0 => 'Propulsé par %s',
      ),
      'Create Account' => 
      array (
        0 => 'Créer un compte',
      ),
      'Station Profile' => 
      array (
        0 => 'Profil de la station',
      ),
      'Genre' => 
      array (
        0 => '',
      ),
      'Web Site URL' => 
      array (
        0 => '',
      ),
      'Note: This should be the public-facing homepage of the radio station, not the AzuraCast URL. It will be included in broadcast details.' => 
      array (
        0 => '',
      ),
      'Enable Public Page' => 
      array (
        0 => 'Activer la page publique',
      ),
      'Show the station in public pages and general API results.' => 
      array (
        0 => '',
      ),
      'URL Stub' => 
      array (
        0 => '',
      ),
      'Optionally specify a short URL-friendly name, such as <code>my_station_name</code>, that will be used in this station\'s URLs. Leave this field blank to automatically create one based on the station name.' => 
      array (
        0 => '',
      ),
      'Number of Recently Played Songs' => 
      array (
        0 => '',
      ),
      'Customize the number of songs that will appear in the "Song History" section for this station and in all public APIs.' => 
      array (
        0 => '',
      ),
      'Select Broadcasting Service' => 
      array (
        0 => '',
      ),
      'Broadcasting Service' => 
      array (
        0 => '',
      ),
      'This software delivers your broadcast to the listening audience.' => 
      array (
        0 => '',
      ),
      'Configure Broadcasting Service' => 
      array (
        0 => '',
      ),
      'Customize Broadcasting Port' => 
      array (
        0 => '',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.' => 
      array (
        0 => 'Aucun autre programme ne peut utiliser ce port. Laissez vide pour assigner automatiquement un port.',
      ),
      'Customize Source Password' => 
      array (
        0 => '',
      ),
      'Leave blank to automatically generate a new password.' => 
      array (
        0 => 'Laissez vide pour générer automatiquement un nouveau mot de passe.',
      ),
      'Customize Administrator Password' => 
      array (
        0 => '',
      ),
      'Maximum Listeners' => 
      array (
        0 => 'Auditeurs maximum',
      ),
      'Maximum number of total listeners across all streams. Leave blank to use the default (250).' => 
      array (
        0 => 'Nombre maximum d\'auditeurs total à travers tous les streams. Laisser vide pour utiliser la valeur par défaut (250).',
      ),
      'Custom Configuration' => 
      array (
        0 => 'Configuration personnalisée',
      ),
      'This code will be included in the frontend configuration. You can use either JSON {"new_key": "new_value"} format or XML &lt;new_key&gt;new_value&lt;/new_key&gt;.' => 
      array (
        0 => 'Ce code sera inclus dans la configuration du frontend. Vous pouvez utiliser le format JSON {"new_key": "new_value"} ou le format XML &lt;new_key&gt;new_value&lt;/new_key&gt;.',
      ),
      'Select AutoDJ Service' => 
      array (
        0 => '',
      ),
      'AutoDJ Service' => 
      array (
        0 => '',
      ),
      'This software shuffles from playlists of music constantly and plays when no other radio source is available.' => 
      array (
        0 => '',
      ),
      'Configure Liquidsoap' => 
      array (
        0 => '',
      ),
      'Crossfade Method' => 
      array (
        0 => '',
      ),
      'Choose a method to use when transitioning from one song to another. Smart Mode considers the volume of the two tracks when fading for a smoother effect, but requires more CPU resources.' => 
      array (
        0 => '',
      ),
      'Smart Mode' => 
      array (
        0 => '',
      ),
      'Normal Mode' => 
      array (
        0 => '',
      ),
      'Disable Crossfading' => 
      array (
        0 => '',
      ),
      'Crossfade Duration (Seconds)' => 
      array (
        0 => 'Durée du fondu enchaîné (en secondes)',
      ),
      'Number of seconds to overlap songs.' => 
      array (
        0 => '',
      ),
      'Apply Compression and Normalization' => 
      array (
        0 => '',
      ),
      'Compress and normalize your station\'s audio, producing a more uniform and "full" sound.' => 
      array (
        0 => '',
      ),
      'Allow Song Requests' => 
      array (
        0 => 'Autoriser la demande du titre suivant',
      ),
      'Enable listeners to request a song for play on your station. Only songs that are already in your playlists are requestable.' => 
      array (
        0 => '',
      ),
      'Request Minimum Delay (Minutes)' => 
      array (
        0 => 'Délai minimum des demandes (en minutes)',
      ),
      'If requests are enabled, this specifies the minimum delay (in minutes) between a request being submitted and being played. If set to zero, no delay is applied.<br><b>Important:</b> Some stream licensing rules require a minimum delay for requests (in the US, this is currently 60 minutes). Check your local regulations for more information.' => 
      array (
        0 => 'Si les demandes sont activées, vous pouvez spécifier un délai (en minutes) entre la demande et le moment où il est joué. Si la valeur est zéro, aucun retard n’est appliqué. <br><b>Important :</b> certaines lois sur la diffusion exigent un délai minimum pour les demandes (aux États-Unis, c’est actuellement à 60 minutes). Veuillez vérifier vos lois locales pour plus d’informations.',
      ),
      'Request Last Played Threshold (Minutes)' => 
      array (
        0 => 'Temps d\'attente avant de redemander un titre (en minutes)',
      ),
      'If requests are enabled, this specifies the minimum time (in minutes) between a song playing on the radio and being available to request again. Set to 0 for no threshold.' => 
      array (
        0 => 'Si les requêtes sont activés, ceci permet de spécifier le temps minimum (en minutes) entre le moment où le titre est joué à la radio et quand il peut être demandé à nouveau. Spécifiez 0 pour aucune attente.',
      ),
      'Allow Streamers / DJs' => 
      array (
        0 => 'Permettre les streamers / DJs',
      ),
      'If enabled, streamers (or DJs) will be able to connect directly to your stream and broadcast live music that interrupts the AutoDJ stream.' => 
      array (
        0 => '',
      ),
      'Deactivate Streamer on Disconnect (Seconds)' => 
      array (
        0 => '',
      ),
      'Number of seconds to deactivate station streamer on manual disconnect. Set to 0 to disable deactivation completely.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Port' => 
      array (
        0 => '',
      ),
      'No other program can be using this port. Leave blank to automatically assign a port.<br><b>Note:</b> The port after this one (n+1) will automatically be used for legacy connections.' => 
      array (
        0 => '',
      ),
      'Customize DJ/Streamer Mount Point' => 
      array (
        0 => '',
      ),
      'If your streaming software requires a specific mount point path, specify it here. Otherwise, use the default.' => 
      array (
        0 => '',
      ),
      'DJ/Streamer Buffer Time (Seconds)' => 
      array (
        0 => '',
      ),
      'The number of seconds of signal to store in case of interruption. Set to the lowest value that your DJs can use without stream interruptions.' => 
      array (
        0 => '',
      ),
      'Character Set Encoding' => 
      array (
        0 => '',
      ),
      'For most cases, use the default UTF-8 encoding. The older ISO-8859-1 encoding can be used if accepting connections from SHOUTcast 1 DJs or using other legacy software.' => 
      array (
        0 => '',
      ),
      'Manual AutoDJ Mode' => 
      array (
        0 => '',
      ),
      'This mode disables AzuraCast\'s AutoDJ management, using Liquidsoap itself to manage song playback. "Next Song" and some other features will not be available.' => 
      array (
        0 => '',
      ),
      'Customize Internal Request Processing Port' => 
      array (
        0 => '',
      ),
      'This port is not used by any external process. Only modify this port if the assigned port is in use. Leave blank to automatically assign a port.' => 
      array (
        0 => '',
      ),
      'Use Replaygain Metadata' => 
      array (
        0 => '',
      ),
      'Instruct Liquidsoap to use any replaygain metadata associated with a song to control its volume level.' => 
      array (
        0 => '',
      ),
      'This code will be inserted into your station\'s Liquidsoap configuration, below the playlist configuration and just before the Icecast output. Only use valid Liquidsoap code for this section!' => 
      array (
        0 => '',
      ),
      'Administration' => 
      array (
        0 => 'Administration',
      ),
      'Enable Broadcasting' => 
      array (
        0 => '',
      ),
      'If disabled, the station will not broadcast or shuffle its AutoDJ.' => 
      array (
        0 => '',
      ),
      'Storage Quota' => 
      array (
        0 => '',
      ),
      'Set a maximum disk space that this station can use. Specify the size with unit, i.e. "8 GB". Units are measured in 1024 bytes. Leave blank to default to the available space on the disk.' => 
      array (
        0 => '',
      ),
      'Base Station Directory' => 
      array (
        0 => '',
      ),
      'The parent directory where station playlist and configuration files are stored. Leave blank to use default directory.' => 
      array (
        0 => '',
      ),
      'Custom Media Directory' => 
      array (
        0 => '',
      ),
      'The directory where media files are stored. Leave blank to use default directory.' => 
      array (
        0 => 'Le répertoire où sont stockés les fichiers multimédias. Laissez vide pour utiliser le répertoire par défaut.',
      ),
      'Streamer Username' => 
      array (
        0 => 'Nom d’utilisateur du streamer',
      ),
      'The streamer will use this username to connect to the radio server.' => 
      array (
        0 => 'Le streamer utilisera ce nom d’utilisateur pour se connecter au serveur radio.',
      ),
      'Streamer Password' => 
      array (
        0 => 'Mot de passe du streamer',
      ),
      'The streamer will use this password to connect to the radio server. Do not use the colon (:) character.' => 
      array (
        0 => '',
      ),
      'Streamer Display Name' => 
      array (
        0 => 'Nom d\'affichage du streamer',
      ),
      'This is the informal display name that will be shown in API responses if the streamer/DJ is live.' => 
      array (
        0 => '',
      ),
      'Internal notes or comments about the user, visible only on this control panel.' => 
      array (
        0 => 'Notes internes ou commentaires au sujet de l’utilisateur, visible uniquement sur ce panneau de contrôle.',
      ),
      'Account is Active' => 
      array (
        0 => 'Le compte est actif',
      ),
      'Enable to allow this account to log in and stream.' => 
      array (
        0 => '',
      ),
      'The display name assigned to this relay when viewing it on administrative or public pages. Leave blank to automatically generate one.' => 
      array (
        0 => '',
      ),
      'Enable to allow listeners to select this relay on this station\'s public pages.' => 
      array (
        0 => '',
      ),
      'Remote Station Type' => 
      array (
        0 => '',
      ),
      'Remote Station Listening URL' => 
      array (
        0 => '',
      ),
      'Example: if the remote radio URL is %s, enter <code>%s</code>.' => 
      array (
        0 => '',
      ),
      'Remote Station Listening Mountpoint/SID' => 
      array (
        0 => '',
      ),
      'Specify a mountpoint (i.e. <code>%s</code>) or a Shoutcast SID (i.e. <code>%s</code>) to specify a specific stream to use for statistics or broadcasting.' => 
      array (
        0 => '',
      ),
      'Broadcast AutoDJ to Remote Station' => 
      array (
        0 => '',
      ),
      'If enabled, the AutoDJ on this installation will automatically play music to this mount point.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Port' => 
      array (
        0 => '',
      ),
      'If the port you broadcast to is different from the one you listed in the URL above, specify the source port here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Mountpoint/SID' => 
      array (
        0 => '',
      ),
      'If the mountpoint (i.e. <code>/radio.mp3</code>) or Shoutcast SID (i.e. <code>2</code>) you broadcast to is different from the one listed above, specify the source mount point here.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Username' => 
      array (
        0 => '',
      ),
      'If you are broadcasting using AutoDJ, enter the source username here. This may be blank.' => 
      array (
        0 => '',
      ),
      'Remote Station Source Password' => 
      array (
        0 => '',
      ),
      'If you are broadcasting using AutoDJ, enter the source password here.' => 
      array (
        0 => '',
      ),
      'Metadata' => 
      array (
        0 => 'Métadonnées',
      ),
      'Full Text' => 
      array (
        0 => 'Texte complet',
      ),
      'Artist Name' => 
      array (
        0 => 'Nom de l’artiste',
      ),
      'Song Metadata' => 
      array (
        0 => 'Métadonnées de la musique',
      ),
      'Song Album' => 
      array (
        0 => 'Album de la musique',
      ),
      'Song Lyrics' => 
      array (
        0 => '',
      ),
      'Replace Album Cover Art' => 
      array (
        0 => '',
      ),
      'ISRC' => 
      array (
        0 => 'ISRC',
      ),
      'International Standard Recording Code, used for licensing reports.' => 
      array (
        0 => 'L\'International Standard Recording Code, utilisé pour les licences de diffusion.',
      ),
      'Administrators can customize the fields that appear here in the <a href="%s">administration page</a>.' => 
      array (
        0 => '',
      ),
      'Control Song Playback' => 
      array (
        0 => '',
      ),
      'Song Length (seconds)' => 
      array (
        0 => 'Durée du titre (en secondes)',
      ),
      'Custom Fading: Overlap Time (seconds)' => 
      array (
        0 => 'Transition en fondu enchaîné : Durée de la superposition (en secondes)',
      ),
      'The time that this song should overlap its surrounding songs when fading. Leave blank to use the system default.' => 
      array (
        0 => 'Indique la durée quand ce titre sera superposé au titre suivant et précédent lors de la transition. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Custom Fading: Fade-In Time (seconds)' => 
      array (
        0 => 'Transition en fondu enchaîné : Durée de la transition de départ (en secondes)',
      ),
      'The time period that the song should fade in. Leave blank to use the system default.' => 
      array (
        0 => 'Indique a quel moment cette musique commencera sa transition de départ. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Custom Fading: Fade-Out Time (seconds)' => 
      array (
        0 => 'Transition en fondu enchaîné : Durée de la transition de fin (en secondes)',
      ),
      'The time period that the song should fade out. Leave blank to use the system default.' => 
      array (
        0 => 'Indique a quel moment cette musique commencera sa transition de fin. Laissez vide pour utiliser la valeur par défaut.',
      ),
      'Custom Cues: Cue-In Point (seconds)' => 
      array (
        0 => 'Repères personnalisés : Début du titre (en secondes)',
      ),
      'Seconds from the start of the song that the AutoDJ should start playing.' => 
      array (
        0 => 'A quel moment, en secondes depuis le début, l\'AutoDJ commencera à lire ce titre.',
      ),
      'Custom Cues: Cue-Out Point (seconds)' => 
      array (
        0 => 'Repères personnalisés : Fin du titre (en secondes)',
      ),
      'Seconds from the start of the song that the AutoDJ should stop playing.' => 
      array (
        0 => 'A quel moment, en secondes depuis le début, l\'AutoDJ arrêtera de lire ce titre.',
      ),
      'Skip to main content' => 
      array (
        0 => '',
      ),
      'Toggle Sidebar' => 
      array (
        0 => 'Afficher/Masquer le panneau latéral',
      ),
      'Toggle Menu' => 
      array (
        0 => '',
      ),
      'Dashboard' => 
      array (
        0 => 'Tableau de bord',
      ),
      'System Administration' => 
      array (
        0 => 'Administration du système',
      ),
      'My Account' => 
      array (
        0 => 'Mon compte',
      ),
      'Switch Theme' => 
      array (
        0 => '',
      ),
      'My API Keys' => 
      array (
        0 => 'Mes clés API',
      ),
      'Help' => 
      array (
        0 => '',
      ),
      'End Session' => 
      array (
        0 => 'Fin de session',
      ),
      'Sign Out' => 
      array (
        0 => 'Se déconnecter',
      ),
      'Like our software? <a href="%s" target="_blank">Donate to support AzuraCast!</a>' => 
      array (
        0 => '',
      ),
      'Mascot designed by %s' => 
      array (
        0 => 'Mascotte conçue par %s',
      ),
      'Need Help?' => 
      array (
        0 => 'Avez-vous besoin d’aide ?',
      ),
      'You can find answers for many common questions in our <a href="%s" target="_blank">support documents</a>.' => 
      array (
        0 => '',
      ),
      'If you\'re experiencing a bug or error, you can submit a GitHub issue using the link below.' => 
      array (
        0 => '',
      ),
      'Your current installation type is <b>%s</b>. Be sure to include this when creating a new issue.' => 
      array (
        0 => '',
      ),
      'New GitHub Issue' => 
      array (
        0 => '',
      ),
      'Pause' => 
      array (
        0 => 'Pause',
      ),
      'Volume' => 
      array (
        0 => '',
      ),
      'AutoDJ' => 
      array (
        0 => 'AutoDJ',
      ),
      'Automatically scroll to the bottom of the log' => 
      array (
        0 => '',
      ),
      'Actions' => 
      array (
        0 => 'Actions',
      ),
      'Log In' => 
      array (
        0 => 'Se connecter',
      ),
      'Edit' => 
      array (
        0 => 'Éditer',
      ),
      'Delete user "%s"?' => 
      array (
        0 => '',
      ),
      'Delete' => 
      array (
        0 => 'Supprimer',
      ),
      '(You)' => 
      array (
        0 => '(Vous)',
      ),
      'Synchronization Tasks' => 
      array (
        0 => '',
      ),
      '%s ago' => 
      array (
        0 => 'il y a %s',
      ),
      'Run Task' => 
      array (
        0 => 'Exécuter la tâche',
      ),
      'Manage Stations' => 
      array (
        0 => 'Gestion des stations',
      ),
      'Manage' => 
      array (
        0 => 'Gérer',
      ),
      'Clone' => 
      array (
        0 => 'Dupliquer',
      ),
      'Delete station "%s"?' => 
      array (
        0 => '',
      ),
      'Delete custom field "%s"?' => 
      array (
        0 => '',
      ),
      'Because you are running Docker, some system logs can only be accessed from a shell session on the host computer. You can run <code>%s</code> to access container logs from the terminal.' => 
      array (
        0 => '',
      ),
      'Logs by Station' => 
      array (
        0 => '',
      ),
      'Owner' => 
      array (
        0 => 'Propriétaire',
      ),
      'Revoke' => 
      array (
        0 => 'Révoquer',
      ),
      'Delete role "%s"?' => 
      array (
        0 => '',
      ),
      'This role cannot be deleted.' => 
      array (
        0 => 'Ce rôle ne peut pas être supprimé.',
      ),
      'Global' => 
      array (
        0 => '',
      ),
      'SHOUTcast Installed' => 
      array (
        0 => '',
      ),
      'The SHOUTcast 2 DNAS is installed and ready for use.' => 
      array (
        0 => 'Le DNAS SHOUTcast 2 est installé et prêt à être utilisé.',
      ),
      'Username' => 
      array (
        0 => 'Nom d’utilisateur',
      ),
      'Notes' => 
      array (
        0 => 'Notes',
      ),
      'Delete streamer "%s"?' => 
      array (
        0 => '',
      ),
      'Connection Information' => 
      array (
        0 => 'Informations de connexion',
      ),
      'IceCast Clients' => 
      array (
        0 => 'Clients IceCast',
      ),
      'Server' => 
      array (
        0 => 'Serveur',
      ),
      'Port' => 
      array (
        0 => 'Port',
      ),
      'Mount Name' => 
      array (
        0 => 'Point de montage',
      ),
      'ShoutCast v1 Clients' => 
      array (
        0 => 'Clients ShoutCast v1',
      ),
      '(DJ username and password separated by a colon)' => 
      array (
        0 => '(Nom du DJ et mot de passe séparés par des deux-points)',
      ),
      'Setup instructions for broadcasting software are available <a href="%s" target="_blank">on the AzuraCast Wiki</a>.' => 
      array (
        0 => 'Des instructions pour la configuration de logiciels de diffusion sont disponibles <a href="%s" target="_blank">sur le Wiki d\'AzuraCast</a>.',
      ),
      'Streamer accounts are currently disabled for this station. To enable streamer accounts, click the button below.' => 
      array (
        0 => 'Les comptes pour les streamers sont actuellement désactivées pour cette station. Pour les activer, cliquez sur le bouton ci-dessous.',
      ),
      'Enable Streaming' => 
      array (
        0 => 'Activer le streaming',
      ),
      'Please wait...' => 
      array (
        0 => 'Veuillez patienter...',
      ),
      'On the Air' => 
      array (
        0 => 'À l\'antenne',
      ),
      'Now Playing' => 
      array (
        0 => 'Titre en cours',
      ),
      'Playing Next' => 
      array (
        0 => 'À suivre',
      ),
      'Now Streaming' => 
      array (
        0 => 'Actuellement en streaming',
      ),
      'Total' => 
      array (
        0 => 'Total',
      ),
      'Unique' => 
      array (
        0 => '',
      ),
      'Skip Song' => 
      array (
        0 => 'Passer ce titre',
      ),
      'Disconnect Streamer' => 
      array (
        0 => 'Déconnecter le streamer',
      ),
      'Copy to Clipboard' => 
      array (
        0 => 'Copier dans le presse-papier',
      ),
      '<a href="%s">Edit station profile</a> to enable.' => 
      array (
        0 => '',
      ),
      'Streamers/DJs' => 
      array (
        0 => 'Streamers/DJs',
      ),
      'Manage streamer accounts' => 
      array (
        0 => '',
      ),
      'Base Directory' => 
      array (
        0 => '',
      ),
      'Media Directory' => 
      array (
        0 => '',
      ),
      'Player Embed Code' => 
      array (
        0 => 'Code du lecteur embarqué',
      ),
      'Streams' => 
      array (
        0 => '',
      ),
      'Local Streams' => 
      array (
        0 => 'Flux locaux',
      ),
      'Play/Pause' => 
      array (
        0 => 'Lecture/Pause',
      ),
      'Download %s' => 
      array (
        0 => 'Télécharger %s',
      ),
      'Icecast (Broadcasting Service)' => 
      array (
        0 => 'Icecast (Diffusion)',
      ),
      'SHOUTcast DNAS 2 (Broadcasting Service)' => 
      array (
        0 => 'SHOUTcast DNAS 2 (Diffusion)',
      ),
      'Loading...' => 
      array (
        0 => '',
      ),
      'Administration URL' => 
      array (
        0 => 'URL de l\'administration',
      ),
      'Administrator Password' => 
      array (
        0 => 'Mot de passe de l\'administrateur',
      ),
      'Source Password' => 
      array (
        0 => 'Mot de passe de la source',
      ),
      'Relay Password' => 
      array (
        0 => '',
      ),
      'Restart' => 
      array (
        0 => 'Redémarrer',
      ),
      'Start' => 
      array (
        0 => 'Démarrer',
      ),
      'Stop' => 
      array (
        0 => 'Arrêter',
      ),
      'AutoDJ Disabled' => 
      array (
        0 => 'AutoDJ désactivé',
      ),
      'AutoDJ has been disabled for this station. No music will automatically be played when a source is not live.' => 
      array (
        0 => 'AutoDJ a été désactivé pour cette station. Aucun musique ne se jouera automatiquement lorsqu’une source n’est pas en direct.',
      ),
      'Liquidsoap (AutoDJ Service)' => 
      array (
        0 => 'Liquidsoap (AutoDJ)',
      ),
      'LiquidSoap is currently shuffling from <b>%d uploaded songs</b> in <b>%d playlists</b>.' => 
      array (
        0 => 'LiquidSoap joue actuellement <b>%d titres</b> dans <b>%d playlists</b>.',
      ),
      'Running' => 
      array (
        0 => 'Lancé',
      ),
      'Not Running' => 
      array (
        0 => 'Arrêté',
      ),
      'Station Broadcasting Disabled' => 
      array (
        0 => '',
      ),
      'Your station is currently not enabled for broadcasting. You can still manage media, playlists, and other station settings. To re-enable broadcasting, <a href="%s">edit your station profile</a>.' => 
      array (
        0 => '',
      ),
      'Automated Playlist Assignment' => 
      array (
        0 => 'Affectation de la playlist automatique',
      ),
      'Based on the previous performance of your station\'s songs, %s can automatically distribute songs evenly among your playlists, placing the highest performing songs in the highest-weighted playlists.' => 
      array (
        0 => 'Basé sur le rendement antérieur des chansons de votre station, %s peut distribuer automatiquement les chansons uniformément dans vos listes de lecture, plaçant les titres les plus performants dans les listes de lecture plus fréquentes.',
      ),
      'Once you have configured automated assignment, click the button below to run the automated assignment process. This process will not run at all unless you have selected "Enable" below.' => 
      array (
        0 => 'Une fois que vous avez configuré l\'affectation automatique, cliquez sur le bouton ci-dessous pour lancer le processus de redistribution automatique. Ce processus ne se lancera pas tant que vous n\'aurez pas activé l\'option ci-dessous.',
      ),
      'Run Automated Assignment' => 
      array (
        0 => 'Exécuter l’affectation automatique',
      ),
      'Configure Automated Assignment' => 
      array (
        0 => 'Configurer l\'affectation automatique',
      ),
      'Mount points are how listeners connect and listen to your station. Each mount point can be a different audio format or quality. Using mount points, you can set up a high-quality stream for broadband listeners and a mobile stream for phone users.' => 
      array (
        0 => '',
      ),
      'Delete mount point "%s"?' => 
      array (
        0 => '',
      ),
      'Default Mount' => 
      array (
        0 => 'Point de montage par défaut',
      ),
      '%s of %s Used' => 
      array (
        0 => '',
      ),
      '%s Files' => 
      array (
        0 => '%s fichiers',
      ),
      'You can also upload files in bulk via SFTP by <a href="%s" target="_blank">following these instructions</a>. Newly uploaded files will automatically be processed within a few minutes.' => 
      array (
        0 => '',
      ),
      'Drag files here to upload to this folder or ' => 
      array (
        0 => 'Glissez ici les fichier à téléverser dans ce dossier ou ',
      ),
      'Set Playlists' => 
      array (
        0 => '',
      ),
      'New Playlist' => 
      array (
        0 => '',
      ),
      'Save' => 
      array (
        0 => '',
      ),
      'Move' => 
      array (
        0 => 'Déplacer',
      ),
      'New Folder' => 
      array (
        0 => 'Nouveau dossier',
      ),
      'Artist' => 
      array (
        0 => 'Artiste',
      ),
      'Album' => 
      array (
        0 => '',
      ),
      'Length' => 
      array (
        0 => 'Durée',
      ),
      'Size' => 
      array (
        0 => 'Taille',
      ),
      'Modified' => 
      array (
        0 => 'Modifié',
      ),
      'New Directory' => 
      array (
        0 => 'Nouveau répertoire',
      ),
      'Directory Name' => 
      array (
        0 => 'Nom du répertoire',
      ),
      'Create Directory' => 
      array (
        0 => 'Créer le répertoire',
      ),
      'Move {{ selected_files }} File(s) to' => 
      array (
        0 => 'Déplacer le(s) fichier(s) {{ selected_files }} vers',
      ),
      'Back' => 
      array (
        0 => 'Retour',
      ),
      'Album Artwork' => 
      array (
        0 => '',
      ),
      'Rename' => 
      array (
        0 => 'Renommer',
      ),
      'Select' => 
      array (
        0 => 'Sélectionner',
      ),
      'Home' => 
      array (
        0 => '',
      ),
      'Remote relays let you work with broadcasting software outside this server. Any relay you include here will be included in your station\'s statistics. You can also broadcast from this server to remote relays.' => 
      array (
        0 => '',
      ),
      'Delete remote relay "%s"?' => 
      array (
        0 => '',
      ),
      'Reorder Playlist' => 
      array (
        0 => '',
      ),
      'Reorder Playlist: %s' => 
      array (
        0 => '',
      ),
      'All Playlists' => 
      array (
        0 => '',
      ),
      'Schedule View' => 
      array (
        0 => 'Calendrier',
      ),
      '# Songs' => 
      array (
        0 => '# Titres',
      ),
      'Delete playlist "%s"?' => 
      array (
        0 => '',
      ),
      'More' => 
      array (
        0 => '',
      ),
      'Disable' => 
      array (
        0 => 'Désactiver',
      ),
      'Enable' => 
      array (
        0 => 'Activer',
      ),
      'Reorder' => 
      array (
        0 => '',
      ),
      'Export %s' => 
      array (
        0 => '',
      ),
      'Song-based' => 
      array (
        0 => '',
      ),
      'Jingle Mode' => 
      array (
        0 => '',
      ),
      'Auto-Assigned' => 
      array (
        0 => 'Auto-assigné',
      ),
      'Weight' => 
      array (
        0 => 'Poids',
      ),
      'Plays between %s and %s' => 
      array (
        0 => 'Joue entre %s et %s',
      ),
      'Once per %d Songs' => 
      array (
        0 => 'Une fois chaque %d Titres',
      ),
      'Once per %d Minutes' => 
      array (
        0 => 'Une fois chaque %d minutes',
      ),
      'Once per Day' => 
      array (
        0 => 'Une fois par jour',
      ),
      'Plays at %s' => 
      array (
        0 => 'Joue à %s',
      ),
      'Custom' => 
      array (
        0 => 'Personnalisé',
      ),
      'Available Logs' => 
      array (
        0 => '',
      ),
      'Web hooks let you connect to external web services and broadcast changes to your station to them.' => 
      array (
        0 => '',
      ),
      'Type' => 
      array (
        0 => 'Type',
      ),
      'Triggers' => 
      array (
        0 => 'Déclencheurs',
      ),
      'Trigger the web hook manually and view the raw response.' => 
      array (
        0 => '',
      ),
      'Test' => 
      array (
        0 => 'Tester',
      ),
      'Delete web hook "%s"?' => 
      array (
        0 => '',
      ),
      'Select the type of web hook to create.' => 
      array (
        0 => '',
      ),
      'Song Duplicates' => 
      array (
        0 => 'Titres en doublon',
      ),
      'No duplicates were found. Nice work!' => 
      array (
        0 => 'Aucun doublon n’a été trouvé. Beau travail !',
      ),
      'Title / File Path' => 
      array (
        0 => 'Titre / Chemin d’accès',
      ),
      'Report Not Available' => 
      array (
        0 => '',
      ),
      'This report is not available for this station, because the system administrator has chosen not to collect detailed IP-based listener information.' => 
      array (
        0 => '',
      ),
      'Listener Request' => 
      array (
        0 => '',
      ),
      'Playlist:' => 
      array (
        0 => '',
      ),
      'Live Broadcast' => 
      array (
        0 => 'Diffusion en direct',
      ),
      'Today' => 
      array (
        0 => 'Aujourd’hui',
      ),
      'Yesterday' => 
      array (
        0 => 'Hier',
      ),
      'Last 7 Days' => 
      array (
        0 => '7 derniers jours',
      ),
      'This Month' => 
      array (
        0 => 'Ce mois-ci',
      ),
      'Last Month' => 
      array (
        0 => 'Le mois dernier',
      ),
      'Listeners by Day' => 
      array (
        0 => 'Auditeurs par jour',
      ),
      'Listeners by Hour' => 
      array (
        0 => 'Auditeurs par heure',
      ),
      'Listeners by Day of Week' => 
      array (
        0 => 'Auditeurs par jour de la semaine',
      ),
      'Best Performing Songs' => 
      array (
        0 => 'Meilleurs titres',
      ),
      'in the last 48 hours' => 
      array (
        0 => 'dans les dernières 48 heures',
      ),
      'Change' => 
      array (
        0 => 'Changer',
      ),
      'Song' => 
      array (
        0 => 'Titre',
      ),
      'Worst Performing Songs' => 
      array (
        0 => 'Pires titres',
      ),
      'Most Played Songs' => 
      array (
        0 => 'Titres les plus joués',
      ),
      'in the last month' => 
      array (
        0 => 'dans le dernier mois',
      ),
      'Plays' => 
      array (
        0 => 'Lectures',
      ),
      'Live Listeners' => 
      array (
        0 => 'Auditeurs en direct',
      ),
      'IP' => 
      array (
        0 => 'IP',
      ),
      'Time (sec)' => 
      array (
        0 => 'Durée (sec)',
      ),
      'User Agent' => 
      array (
        0 => 'User-Agent',
      ),
      'Location' => 
      array (
        0 => 'Localité',
      ),
      'Mobile Device' => 
      array (
        0 => '',
      ),
      'Desktop Device' => 
      array (
        0 => '',
      ),
      'Unknown' => 
      array (
        0 => 'Inconnu',
      ),
      'This product includes GeoLite2 data created by MaxMind, available from %s.' => 
      array (
        0 => '',
      ),
      'Listener' => 
      array (
        0 => 'Auditeur',
      ),
      'Download CSV' => 
      array (
        0 => 'Télécharger le CSV',
      ),
      'Date/Time' => 
      array (
        0 => 'Date/Heure',
      ),
      'Filename' => 
      array (
        0 => 'Nom de fichier',
      ),
      'Length Text' => 
      array (
        0 => 'Longueur du texte',
      ),
      'Playlist(s)' => 
      array (
        0 => 'Playlist(s)',
      ),
      'Joins' => 
      array (
        0 => 'Arrivées',
      ),
      'Losses' => 
      array (
        0 => 'Départs',
      ),
      'Play %' => 
      array (
        0 => '% lectures',
      ),
      'Ratio' => 
      array (
        0 => 'Ratio',
      ),
      'Date Requested' => 
      array (
        0 => 'Date demandée',
      ),
      'Date Played' => 
      array (
        0 => 'Date de lecture',
      ),
      'Requester IP' => 
      array (
        0 => 'IP du demandeur',
      ),
      'Not Played' => 
      array (
        0 => 'Pas joué',
      ),
      'Daily Listener Range' => 
      array (
        0 => 'Rangée d\'auditeurs journalière',
      ),
      'Hourly Average Listeners' => 
      array (
        0 => 'Moyenne d\'auditeurs horaire',
      ),
      'Daily Average Listeners' => 
      array (
        0 => 'Moyenne d\'auditeurs journalière',
      ),
      'Average Listeners' => 
      array (
        0 => 'Moyenne d\'auditeurs',
      ),
      'Cued On' => 
      array (
        0 => '',
      ),
      'Delete queue item?' => 
      array (
        0 => '',
      ),
      'API keys can be used to access some system functionality without needing to log in. All of the keys 
            you create share your permissions in the system. For more information, see the <a href="%s">API documentation</a>.' => 
      array (
        0 => '',
      ),
      'Key Identifier' => 
      array (
        0 => '',
      ),
      'New Key Generated' => 
      array (
        0 => '',
      ),
      '<b>Important: copy the key below before continuing!</b> You will not be able to retrieve it again.' => 
      array (
        0 => '',
      ),
      'Your full API key is below:' => 
      array (
        0 => '',
      ),
      'When making API calls, you can pass this value in the "X-API-Key" header to authenticate as yourself. You can only perform the actions your user account is allowed to perform.' => 
      array (
        0 => '',
      ),
      'Continue' => 
      array (
        0 => 'Continuer',
      ),
      'AzuraCast First-Time Setup' => 
      array (
        0 => '',
      ),
      'Welcome to AzuraCast!' => 
      array (
        0 => '',
      ),
      'Let\'s get started by creating your Super Administrator account.' => 
      array (
        0 => '',
      ),
      'This account will have full access to the system, and you\'ll automatically be logged in to it for the rest of setup.' => 
      array (
        0 => '',
      ),
      'AzuraCast Setup' => 
      array (
        0 => 'Configuration d\'AzuraCast',
      ),
      'Create Station' => 
      array (
        0 => '',
      ),
      'Create a New Radio Station' => 
      array (
        0 => '',
      ),
      'Continue the setup process by creating your first radio station below. You can edit any of these details later.' => 
      array (
        0 => 'Poursuivez le processus de configuration en créant votre première station de radio ci-dessous. Vous pourrez modifier ces détails plus tard.',
      ),
      'Customize AzuraCast Settings' => 
      array (
        0 => '',
      ),
      'Complete the setup process by providing some information about your broadcast environment. These settings can be changed later from the administration panel.' => 
      array (
        0 => 'Compléter le processus d’installation en fournissant des informations sur votre environnement de diffusion. Ces paramètres peuvent être modifiés ultérieurement depuis le panneau d’administration.',
      ),
      'Listeners Across All Stations' => 
      array (
        0 => 'Auditeurs à travers toutes les stations',
      ),
      'Listeners Per Station' => 
      array (
        0 => 'Auditeurs par station',
      ),
      'Station Overview' => 
      array (
        0 => 'Vue d’ensemble de la station',
      ),
      'Options' => 
      array (
        0 => 'Options',
      ),
      'Error: No Available Stations' => 
      array (
        0 => 'Erreur : Aucune station disponible',
      ),
      'Your account is active, but is not currently associated with any stations. If you believe this is an error, please contact this server\'s administrator.' => 
      array (
        0 => 'Votre compte est actif, mais n\'est actuellement associé à aucune station. Si vous pensez qu\'il s\'agit d\'une erreur, veuillez contacter l\'administrateur du serveur.',
      ),
      'Customize' => 
      array (
        0 => '',
      ),
      'Two-Factor Authentication' => 
      array (
        0 => '',
      ),
      'Two-factor authentication improves the security of your account by requiring a second one-time access code in addition to your password when you log in.' => 
      array (
        0 => '',
      ),
      'Disable Two-Factor' => 
      array (
        0 => '',
      ),
      'Enable Two-Factor' => 
      array (
        0 => '',
      ),
      'Enable Two-Factor Authentication' => 
      array (
        0 => '',
      ),
      'Step 1: Scan QR Code' => 
      array (
        0 => '',
      ),
      'From your smartphone, scan the code to the right using an authentication app of your choice (FreeOTP, Authy, etc).' => 
      array (
        0 => '',
      ),
      'Step 2: Verify Generated Code' => 
      array (
        0 => '',
      ),
      'To verify that the code was set up correctly, enter the 6-digit code the app shows you.' => 
      array (
        0 => '',
      ),
      'Song History' => 
      array (
        0 => 'Historique des titres',
      ),
      'Request Song' => 
      array (
        0 => 'Demander un titre',
      ),
      'Request a Song' => 
      array (
        0 => 'Demander un titre',
      ),
      'Album Cover' => 
      array (
        0 => '',
      ),
      'Mute' => 
      array (
        0 => 'Mettre en sourdine',
      ),
      'Full Volume' => 
      array (
        0 => '',
      ),
      'Request' => 
      array (
        0 => 'Demander',
      ),
      'Microphone' => 
      array (
        0 => '',
      ),
      'Mixer' => 
      array (
        0 => '',
      ),
      'Playlist 1' => 
      array (
        0 => '',
      ),
      'Playlist 2' => 
      array (
        0 => '',
      ),
      'Encoder' => 
      array (
        0 => 'Encodeur',
      ),
      'MP3' => 
      array (
        0 => '',
      ),
      'Raw' => 
      array (
        0 => '',
      ),
      'Sample Rate' => 
      array (
        0 => 'Fréquence d\'échantillonnage',
      ),
      'Bit Rate' => 
      array (
        0 => 'Débit',
      ),
      'DJ Credentials' => 
      array (
        0 => '',
      ),
      'Use Asynchronous Worker' => 
      array (
        0 => '',
      ),
      'Continuous Play' => 
      array (
        0 => '',
      ),
      'Repeat Playlist' => 
      array (
        0 => '',
      ),
      'Microphone Source' => 
      array (
        0 => '',
      ),
      'Start Streaming' => 
      array (
        0 => '',
      ),
      'Stop Streaming' => 
      array (
        0 => '',
      ),
      'Cue' => 
      array (
        0 => '',
      ),
      'Update Metadata' => 
      array (
        0 => '',
      ),
      'Add Files to Playlist' => 
      array (
        0 => '',
      ),
      'Unknown Title' => 
      array (
        0 => 'Titre inconnu',
      ),
      'Unknown Artist' => 
      array (
        0 => 'Artiste inconnu',
      ),
      'Welcome!' => 
      array (
        0 => 'Bienvenue!',
      ),
      'Welcome to %s!' => 
      array (
        0 => 'Bienvenue sur %s !',
      ),
      'Please log in to continue.' => 
      array (
        0 => 'Veuillez vous connecter pour continuer.',
      ),
      '<a href="%s" target="_blank">Forgot your password?</a>' => 
      array (
        0 => '<a href="%s" target="_blank">vous avez oublié votre mot de passe ?</a>',
      ),
      'Enter Two-Factor Code' => 
      array (
        0 => '',
      ),
      'Your account uses a two-factor security code. Enter the code your device is currently showing below.' => 
      array (
        0 => '',
      ),
      'Security Code' => 
      array (
        0 => '',
      ),
      'The page you requested was not found.' => 
      array (
        0 => 'La page que vous avez demandée n\'a pas été trouvée.',
      ),
      'Select...' => 
      array (
        0 => 'Sélectionner...',
      ),
      'No results found!' => 
      array (
        0 => 'Aucun résultat trouvé!',
      ),
    ),
  ),
);